const express = require("express")

const PORT = 8000

const app = express()

// a middleware
function logger(req, res, next){
    console.log(`REQ OBJ: ${req.originalUrl} ${req.path} ${req.method} ${req.baseUrl}`)
    next()
}

// using a middleware for all APIs
app.use(logger)

app.get("/", (req, res) => {
    res.send("Hello from server!")
})

app.get("/greetings", (req, res) => {
    res.send("Greetings! Server is running.")
})

app.listen(PORT, function() {
    console.log("app is listening on port " + PORT)
})